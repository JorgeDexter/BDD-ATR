export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyABAvj13tO6mdZZYd79EIy3mKqj0RrHNaI",
  authDomain: "bdd-atr.firebaseapp.com",
  databaseURL: "https://bdd-atr-default-rtdb.firebaseio.com",
  projectId: "bdd-atr",
  storageBucket: "bdd-atr.appspot.com",
  messagingSenderId: "594964601880",
  appId: "1:594964601880:web:5e2cc54d0470d7197db76d",
  }
};