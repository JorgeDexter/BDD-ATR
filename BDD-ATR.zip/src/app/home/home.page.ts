import { Component } from '@angular/core';
import { Database, ref, object, set } from '@angular/fire/database';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  casa: any = {
    Baño: { estado: false },
    Cocina: { estado: false },
    Comedor: { estado: false },
    Dormitorio: { estado: false }
  };

  constructor(private database: Database) {}

  ngOnInit() {
    // Suscribirse a los cambios en cada área de la casa
    Object.keys(this.casa).forEach(area => {
      const areaRef = ref(this.database, `/casa/${area}`);
      object(areaRef).subscribe(attributes => {
        const currentValue = attributes.snapshot.val();
        this.casa[area].estado = currentValue;
      });
    });
  }

  Estado(location: string) {
    const locationRef = ref(this.database, `/casa/${location}`);
    object(locationRef).pipe(
      take(1)
    ).subscribe(attributes => {
      const currentValue = attributes.snapshot.val();
      set(locationRef, !currentValue).then(() => {
        console.log(`Estado de ${location} actualizado en la base de datos`);
      }).catch(error => {
        console.error('Error al actualizar el estado en la base de datos:', error);
      });
    });
  }
}

